import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class JsonPlotter extends PApplet {




GraphContainer gContainer;
TextBox textBox;

float[] testData = new float[20];
float sf = 1.0f;

Serial myPort; 

public void mousePressed(){
  if (overRect(0, 0, 100, 100)){
    String[] s = loadStrings("sample.json");
    if(s != null){
      for(int i=0;i<s.length;i++){
        textBox.addText(s[i]);
      }
    }
  }
}


//interface setup
int offset = 40;
float golRatio = 0.61f;

public void setup() {
  
  background(0,0,0);
  
  gContainer = new GraphContainer(0,offset,PApplet.parseInt(width*golRatio), height - offset,4);

  rect(0,0,offset,offset);
  textBox = new TextBox(PApplet.parseInt(width*golRatio), 0, PApplet.parseInt(width*(1-golRatio)), height);
  
  String[] portNames = Serial.list(); 
  if(portNames.length > 0)
    myPort = new Serial(this, portNames[0], 115200);
  else 
    myPort = null;
  
}

public void draw(){
  if ( myPort != null){
    while ( myPort.available() > 0) {  // If data is available,
      textBox.addText(myPort.readChar());
    }
  }
  
  sf += 0.01f;
  for(int i=0;i<testData.length;i++){
    testData[i] = sin(i/sf);
  }
  
  JSONObject[] jsonArray = textBox.getJsonObjects();
  gContainer.handleJson(jsonArray);
  
  //text(int(frameRate),width-100,10);

}

public void drawDebugData(int x, int y){};

class TextBox {
  //String buffer;
  int x,y,w,h;
  int maxLen;
  static final int lineH = 15;
  ArrayList<String> textLines;
  ArrayList<JSONObject> jsons;

  public int countChars(String s, char c){//veeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
    int count = s.length() - s.replace(""+c, "").length();//eeeeeeeeeeeeeeeeee
    return count;//eeeeeeeeeeeeeeery dirty hack but works thanks stackOverflow.
  }
  
  public String findJson(){
    return findJson(textLines.size());
  }
  
  public String findJson(int endLine){
    String buffer = "";
    int bracketCounter = 0;
    endLine--;
    while(endLine >= 0){
      buffer = textLines.get(endLine) + buffer;
      bracketCounter += countChars(textLines.get(endLine),'}');
      bracketCounter -= countChars(textLines.get(endLine),'{');
      if(bracketCounter == 0)//json file ended
        endLine = 0;
      endLine--;
      }
    if(endLine <0){//buffer should contain valid JSON!
      println(buffer.replace("#",""));
      return buffer.replace("#","");
    }
    else
      return null;
    }
      
      
  TextBox(int x,int y,int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    textLines = new ArrayList<String>();
    textLines.add("init");
    maxLen = h/lineH;
    jsons = new ArrayList<JSONObject>();
    redraw();
  }
  
  public void addText(char c){
    if (c == '\n'){
      textLines.add("");
      if (textLines.size() > maxLen)
        textLines.remove(0);
    }
    else{
      String s = textLines.get(textLines.size());
      s +=c;
      if(c =='#'){
        JSONObject j;// = new JSONObject();
        j = parseJSONObject(findJson());
        jsons.add(j);
      }
    }
  }
    
  public void addText(String text){
    String[] buffer = text.split("\n");
    for(int i=0;i<buffer.length;i++){
      textLines.add(buffer[i].replaceAll("\t", "    "));
      if (textLines.size() > maxLen)
        textLines.remove(0);
      if(buffer[i].contains("#")){
        JSONObject j;// = new JSONObject();
        j = parseJSONObject(findJson());
        //print(j);
        jsons.add(j);
        //print(jsons.get(0));
      }
    }
    redraw();
  }
  
  public JSONObject[] getJsonObjects(){
    JSONObject[] temp = jsons.toArray(new JSONObject[jsons.size()]);
    jsons.clear();
    return temp;
  }
  
  public void redraw(){
    fill(0, 0, 0);
    rect(x,y,w,h);
    fill(200, 200, 200);
    //textAlign(LEFT, BOTTOM);
    for(int i=0;i<textLines.size();i++){
      text(textLines.get(i), x,y+lineH*i,w,lineH);
    }
  }
  
}
class Graph {
  int x,y, h, l;
  
  String name = "noName";
  Graph(int setX, int setY, int setW, int setH){
    x = setX;
    y = setY;
    l = setW;
    h = setH;
    sampleData = new float[l];
    redraw();
  }
  
  
  
  float sampleData[];
  
  public void redraw(){redraw(0);}
  
  public void redraw(int mode){
    //mode 0 - waveform - typical audio data
    //mode 1 - absolute data, drawn with bars, typical FFT data
    fill(204, 102, 0);
    rect(x,y,l,h);
    int yMid = y+(h/2);
    
    float absMaxValue = 0;
    for(int i=0;i<sampleData.length;i++){
      if (abs(sampleData[i]) > absMaxValue)
        absMaxValue = sampleData[i];
    }
    float scaleFactor = (h/2)/absMaxValue;
    fill(0,0,200);
    
    text(String.format("-%.2f",absMaxValue),x+5,yMid+h/3,100,100);
    text(String.format("+%.2f",absMaxValue),x+5,yMid-h/3,100,100);
    
    for(int i=1;i<sampleData.length;i++){
      int x1 = x+i-1;
      int x2 = x+i;
      int y1 = yMid+PApplet.parseInt(sampleData[i-1]*scaleFactor);
      int y2 = yMid+PApplet.parseInt(sampleData[i]*scaleFactor);
      line(x1,y1,x2,y2);
    }
  
  text(name, x+5,y+5,400,50);
  }
  
  //scaleData(float dataIn[], float dataOut[], float scaleFactor = 0){
  //  int sizeIn = dataIn.length;
  //  int sizeOut = dataOut.length;
  //  if (scaleFactor == 0) 
  //        scaleFactor = sizeOut/sizeIn;
  //  for (int i=0;i<sizeIn;i++){
      
  public void fillWithData(float data[]){fillWithData(data,1);}
  
  public void fillWithData(float data[], int dataType){
    int i=0;
    //fill internal buffer with zeros
    for (i=0;i<data.length;i++)
      sampleData[i] = 0.0f;
    i = 0;
    if (data.length>sampleData.length)
      i = data.length - sampleData.length;//ignore some samples, or stretch data?
    for (;i<data.length;i++){
      sampleData[i] = data[i];
    }
    redraw();
  }
  
  public void appendData(float data[]){appendData(data,1);}
  
  public void appendData(float data[], int dataType){
    if (data.length > sampleData.length)
      fillWithData(data,dataType);
    else{
      //shift array to make space for new samples
      int sizeDiff = sampleData.length - data.length;
      for(int i=0;i<sizeDiff;i++)
        sampleData[i] = sampleData[i+data.length];
      //append sample array with new samples
      for(int i=0;i<data.length;i++)
        sampleData[sizeDiff+i] = data[i];
      redraw();
    }
  }
}


class GraphContainer{
  int x,y,w,h;
  Graph graphs[];
  
  GraphContainer(int x, int y, int w, int h, int graphNo){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    graphs = new Graph[graphNo];
    for (int i = 0;i<graphs.length;i++)
      graphs[i] = new Graph(x,y+i*(h/graphNo),w,h/graphNo);
  }
  
  public void handleJson(JSONObject[] jArray){
    for(int iJsons = 0; iJsons < jArray.length; iJsons++){
      JSONObject j = jArray[iJsons].getJSONObject("Packet");
      if (j==null){
        print("wrong JSON object!");
      }
      else{
       print("printing json data\n\n");
       print(j);
       String type = j.getString("type","DataErr");
       String name = j.getString("name","DataErr");
       int dataSize = j.getInt("dataSize",0);
       
       float[] data = new float[dataSize];
       
       JSONArray jData = j.getJSONArray("data");
       if(jData != null){
         for(int k=0;k<dataSize;k++)
           data[k] = jData.getInt(k,0);
       }   
       boolean graphNameFound = false;
       //try to find an graph that already has this name
       for(int i = 0;i<graphs.length;i++){
         if (graphs[i].name.equals(name)){
           //if found, append with new data
           graphs[i].appendData(data);
           graphNameFound = true;
           break;
         }
       }
       
       if(graphNameFound == false){
         //graph has not been found, try to claim a new graph
         boolean graphCreated = false;
         for(int i = 0;i<graphs.length;i++){
           if (graphs[i].name.equals("noName")){
               //claim empty graph
               graphs[i].name = name;
               graphs[i].appendData(data);
               graphCreated = true;
               break;
           }
           if (graphCreated ==false)
             print("no available graphs for this data:"+j);
         }
       }
      }
    }
  }
  
  
}


public boolean overRect(int x, int y, int width, int height)  {
  if (mouseX >= x && mouseX <= x+width && 
      mouseY >= y && mouseY <= y+height) {
    return true;
  } else {
    return false;
  }
}
  public void settings() {  size(1024, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "JsonPlotter" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
